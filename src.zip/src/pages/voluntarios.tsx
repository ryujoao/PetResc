import Layout from "../components/layout";



export default function Voluntarios() {
  return (
    <>
    <Layout>
      <div style={{ padding: '2rem' }}>
        <h1>Sobre</h1>
        <p>Informações sobre o projeto e a equipe.</p>
      </div>
      </Layout>
    </>
  );
}
